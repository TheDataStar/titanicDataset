
#### EVFE Project on titanic dataset from kaggle.


```
library(ggplot2)
```

    Warning message:
    "package 'ggplot2' was built under R version 3.6.3"


```
titanic <- read.csv("train.csv")
head(titanic)
```


<table>
<thead><tr><th scope=col>PassengerId</th><th scope=col>Survived</th><th scope=col>Pclass</th><th scope=col>Name</th><th scope=col>Sex</th><th scope=col>Age</th><th scope=col>SibSp</th><th scope=col>Parch</th><th scope=col>Ticket</th><th scope=col>Fare</th><th scope=col>Cabin</th><th scope=col>Embarked</th></tr></thead>
<tbody>
	<tr><td>1                                                  </td><td>0                                                  </td><td>3                                                  </td><td>Braund, Mr. Owen Harris                            </td><td>male                                               </td><td>22                                                 </td><td>1                                                  </td><td>0                                                  </td><td>A/5 21171                                          </td><td> 7.2500                                            </td><td>                                                   </td><td>S                                                  </td></tr>
	<tr><td>2                                                  </td><td>1                                                  </td><td>1                                                  </td><td>Cumings, Mrs. John Bradley (Florence Briggs Thayer)</td><td>female                                             </td><td>38                                                 </td><td>1                                                  </td><td>0                                                  </td><td>PC 17599                                           </td><td>71.2833                                            </td><td>C85                                                </td><td>C                                                  </td></tr>
	<tr><td>3                                                  </td><td>1                                                  </td><td>3                                                  </td><td>Heikkinen, Miss. Laina                             </td><td>female                                             </td><td>26                                                 </td><td>0                                                  </td><td>0                                                  </td><td>STON/O2. 3101282                                   </td><td> 7.9250                                            </td><td>                                                   </td><td>S                                                  </td></tr>
	<tr><td>4                                                  </td><td>1                                                  </td><td>1                                                  </td><td>Futrelle, Mrs. Jacques Heath (Lily May Peel)       </td><td>female                                             </td><td>35                                                 </td><td>1                                                  </td><td>0                                                  </td><td>113803                                             </td><td>53.1000                                            </td><td>C123                                               </td><td>S                                                  </td></tr>
	<tr><td>5                                                  </td><td>0                                                  </td><td>3                                                  </td><td>Allen, Mr. William Henry                           </td><td>male                                               </td><td>35                                                 </td><td>0                                                  </td><td>0                                                  </td><td>373450                                             </td><td> 8.0500                                            </td><td>                                                   </td><td>S                                                  </td></tr>
	<tr><td>6                                                  </td><td>0                                                  </td><td>3                                                  </td><td>Moran, Mr. James                                   </td><td>male                                               </td><td>NA                                                 </td><td>0                                                  </td><td>0                                                  </td><td>330877                                             </td><td> 8.4583                                            </td><td>                                                   </td><td>Q                                                  </td></tr>
</tbody>
</table>



### Check data type.
Following the initial pull of the dataset into the notebook then calling head to view the basic table. We want to check data types and begin our exploration and feature engineering process. We do this first by calling the str method (struct) in R to determine the data types of each vector. Carefully looking at each individual one to see if it has any relevance to our hypothesis or business need. Make sure to ask questions like " Does this data type correctly portray the naming and value conventions its trying to exhibit". 


```
str(titanic)
```

    'data.frame':	891 obs. of  12 variables:
     $ PassengerId: int  1 2 3 4 5 6 7 8 9 10 ...
     $ Survived   : int  0 1 1 1 0 0 0 0 1 1 ...
     $ Pclass     : int  3 1 3 1 3 3 1 3 3 2 ...
     $ Name       : Factor w/ 891 levels "Abbing, Mr. Anthony",..: 109 191 358 277 16 559 520 629 417 581 ...
     $ Sex        : Factor w/ 2 levels "female","male": 2 1 1 1 2 2 2 2 1 1 ...
     $ Age        : num  22 38 26 35 35 NA 54 2 27 14 ...
     $ SibSp      : int  1 1 0 1 0 0 0 3 0 1 ...
     $ Parch      : int  0 0 0 0 0 0 0 1 2 0 ...
     $ Ticket     : Factor w/ 681 levels "110152","110413",..: 524 597 670 50 473 276 86 396 345 133 ...
     $ Fare       : num  7.25 71.28 7.92 53.1 8.05 ...
     $ Cabin      : Factor w/ 148 levels "","A10","A14",..: 1 83 1 57 1 1 131 1 1 1 ...
     $ Embarked   : Factor w/ 4 levels "","C","Q","S": 4 2 4 4 4 3 4 4 4 2 ...
    

In the above struct call, the "survived" vector is cast as an int data type with a value of 0 or 1. We want to type cast this as a factor(Object) instead. We to this to create more meaningful categories or labels for our data set.


```
titanic$Survived <- as.factor(titanic$Survived) # Calling titanic variable, survived category and using as.factor to re-cast it.
```


```
# Renaming factor levels.
levels(titanic$Survived) <- c("Dead", "Survived")
levels(titanic$Embarked) <- c("Unknown", "Cherbourg", "Queenstown", "Southampton")

str(titanic[,c("Embarked", "Survived")])
```

    'data.frame':	891 obs. of  2 variables:
     $ Embarked: Factor w/ 4 levels "Unknown","Cherbourg",..: 4 2 4 4 4 3 4 4 4 2 ...
     $ Survived: Factor w/ 2 levels "Dead","Survived": 1 2 2 2 1 1 1 1 2 2 ...
    


```
# Checking class distribution using pie chart
survivedTable <- table(titanic$Survived)
pie(survivedTable, labels=c("Died", "Survived"))
```


![png](output_8_0.png)


Now that we have cleaned up the data set a bit and done some inital exploration and visualization, its time to ask some questions. Is sex a good predictor of surviviability is a good place to start. Were going to use a segmentated bar graph to visualize this. To do this we create a variable called sex.survived.plt we then call ggplot to pull information from the titanic variable which contains our train.csv dataset. we call aesthetic (aes) to plot the "Sex" vector and fill the "survived" value we created previously as a different color.


```
sex.survived.plt <- ggplot(titanic, aes(x=Sex, fill=Survived))
sex.survived.plt + geom_bar()
```


![png](output_10_0.png)


We can then use facet wrap to stitch two plots together. 


```
survived.sex.plt <- ggplot(titanic, aes(x=Survived, fill=Sex))
survived.sex.plt + geom_bar() + facet_wrap(~Sex)
```


![png](output_12_0.png)



```
# Same concept as above but faceting with Embarked vector.
survived.sex.plt + geom_bar() + facet_wrap(~Embarked)
```


![png](output_13_0.png)



```
# Facet_wrap() takes only a single variable so using facet_grid(), facetes multiple different variables simultaneously.
survived.sex.plt + geom_bar() + facet_grid(Sex ~ Embarked)
```


![png](output_14_0.png)



```
# Age ranges & predictor of survivability.
summary(titanic$Age)
summary(titanic[titanic$Survived=="Dead,"]$Age)
summary(titanic[titanic$Survived=="Survived",]$Age)
```


       Min. 1st Qu.  Median    Mean 3rd Qu.    Max.    NA's 
       0.42   20.12   28.00   29.70   38.00   80.00     177 



    Length  Class   Mode 
         0   NULL   NULL 



       Min. 1st Qu.  Median    Mean 3rd Qu.    Max.    NA's 
       0.42   19.00   28.00   28.34   36.00   80.00      52 



```
age.sex.plt <- ggplot(titanic, aes(x=Age, fill=Sex)) + geom_histogram()
age.sex.plt + labs(x="Distribution  of Age", y="Frequency Bucket", title="Distribution of Passanger Ages on Titanic")
```

    `stat_bin()` using `bins = 30`. Pick better value with `binwidth`.
    Warning message:
    "Removed 177 rows containing non-finite values (stat_bin)."


![png](output_16_1.png)



```
# Ages impact on survivability cont.
survived.age.plt <- ggplot(titanic, aes(x=Survived, y=Age))
survived.age.plt + geom_boxplot()
```

    Warning message:
    "Removed 177 rows containing non-finite values (stat_boxplot)."


![png](output_17_1.png)



```
# Same plot using density curve as visualization.
age.survived.plt <- ggplot(titanic, aes(x=Age, color=Survived))
age.survived.plt + geom_density() + ylab("Density")
```

    Warning message:
    "Removed 177 rows containing non-finite values (stat_density)."


![png](output_18_1.png)



```
# Segmenting further by adding sex and embarked on top of age of survivability.
age.survived.plt + geom_density() + facet_grid(Sex ~ Embarked) + ylab("Density")
```

    Warning message:
    "Removed 177 rows containing non-finite values (stat_density)."Warning message:
    "Groups with fewer than two data points have been dropped."


![png](output_19_1.png)



```

```
